import { Injectable } from '@angular/core';

import { HttpClient, HttpErrorResponse } from '@angular/common/http';

import { IUser } from '../../quickKart-interfaces/user';

import { ICart } from '../../quickKart-interfaces/cart';

import { catchError } from 'rxjs/operators';

import { Observable, throwError } from 'rxjs';

import { ICartProduct } from '../../quickKart-interfaces/cartProduct';



@Injectable({
� providedIn: 'root'
})

export class UserService {

� 
constructor(private http: HttpClient) { }

�
 validateCredentials(id: string, password: string): Observable<string>
{
� 
� var userObj: IUser;
� �
 userObj = { EmailId: id, UserPassword: password, Gender: null, RoleId: null, DateOfBirth: null, Address: null };
�
 � return this.http.post<string>('http://localhost:11990/api/user/ValidateUserCredentials', userObj).pipe(catchError(this.errorHandler));

� }

� 

addProductToCart(productId: string, emailId: string): Observable<boolean> 
{
� �
var cartObj: ICart;
� � 
cartObj = { ProductId: productId, EmailId: emailId, Quantity: 1 };
� 
 return this.http.post<boolean>('http://localhost:11990/api/user/AddProductToCart', cartObj).pipe(catchError(this.errorHandler));
�

 }

�


 getCartProducts(emailId: string): Observable<ICartProduct[]> {
�
 � let param = "?emailId=" + emailId;
� 
� return this.http.get<ICartProduct[]>('http://localhost:11990/api/user/GetCartProducts' + param).pipe(catchError(this.errorHandler));
�
 }





errorHandler(error: HttpErrorResponse) 
{
� � 
console.error(error);
�
 � return throwError(error.message || "Server Error");

� }�

}